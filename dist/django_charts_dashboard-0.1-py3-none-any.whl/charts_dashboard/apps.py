from django.apps import AppConfig


class DjChartjsConfig(AppConfig):
    name = "charts"
