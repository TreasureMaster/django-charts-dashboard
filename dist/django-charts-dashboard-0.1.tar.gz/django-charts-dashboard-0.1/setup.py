from setuptools import setup

setup(
    test_suite="runtests.runtests",
)