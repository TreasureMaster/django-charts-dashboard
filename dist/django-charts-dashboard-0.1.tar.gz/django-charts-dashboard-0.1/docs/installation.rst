============
Installation
============

At the command line::

    $ pip install django-charts-dashboard
    $ easy_install django-charts-dashboard
    $ pipenv install django-charts-dashboard

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv venv
    $ pip install django-charts-dashboard
